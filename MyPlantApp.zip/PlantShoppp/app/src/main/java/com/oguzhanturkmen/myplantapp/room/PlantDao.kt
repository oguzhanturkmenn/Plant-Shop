package com.oguzhanturkmen.myplantapp.room

import androidx.lifecycle.LiveData
import androidx.room.*
import com.oguzhanturkmen.myplantapp.data.models.Plant

@Dao
interface PlantDao {

    @Query("SELECT * FROM room_plant WHERE plant_fav = 0 ORDER BY plant_id DESC")
    fun getAllBasket(): LiveData<List<Plant>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveBasket(plant: Plant)

    @Query("SELECT SUM(count * plant_price) FROM room_plant")
    suspend fun getTotalPrice(): Int

    @Update
    suspend fun updateBasket(plant: Plant) // For count in adapter

    @Query("SELECT * FROM room_plant WHERE plant_name = :plantName")
    suspend fun getPlantByName(plantName: String): Plant

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addToFav(plant: Plant)

    @Query("SELECT * FROM room_plant WHERE plant_fav = 1 ORDER BY plant_id DESC")
    suspend fun getAllFav(): List<Plant>

    @Query("SELECT plant_name FROM room_plant")
    suspend fun getFavTitles(): List<String>?

    @Query("SELECT * FROM room_plant WHERE plant_name LIKE :query ORDER BY plant_id DESC")
    fun searchPlant(query: String?): List<Plant>

    @Query("UPDATE room_plant SET plant_count=:count WHERE plant_name = :name")
    fun updatePlant(count: Int, name: String)

    @Query("DELETE FROM room_plant WHERE plant_id = :id")
    suspend fun deletePlant(id: Int)

    @Query("DELETE FROM room_plant WHERE plant_name = :name")
    suspend fun deleteFromBasket(name: String)

    @Delete
    suspend fun deleteFromFav(plant: Plant)

}