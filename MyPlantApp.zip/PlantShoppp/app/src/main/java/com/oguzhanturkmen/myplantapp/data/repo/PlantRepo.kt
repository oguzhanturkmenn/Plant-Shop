package com.oguzhanturkmen.myplantapp.data.repo

import androidx.lifecycle.LiveData
import com.oguzhanturkmen.myplantapp.data.datasource.PlantDataSource
import com.oguzhanturkmen.myplantapp.data.models.Plant

class PlantRepo(var dataSource: PlantDataSource) {

    suspend fun loadPlants(): List<Plant> {
        val favoriteNamesList = dataSource.plantDao.getFavTitles().orEmpty()
        return dataSource.loadPlants().map {
            with(it) {
                Plant(
                    id,
                    plantDescription,
                    plantImage,
                    plantPrice,
                    plantName,
                    plantCount,
                    plantEmail,
                    favoriteNamesList.contains(plantName)
                )
            }

        }
    }

    suspend fun loadFavPlants(): List<Plant> = dataSource.loadFavPlants()

    val readAllBasket: LiveData<List<Plant>> = dataSource.plantDao.getAllBasket()

    suspend fun addToFav(plant: Plant) = dataSource.addToFav(plant)

    suspend fun addToBasket(plant: Plant) = dataSource.addToBasket(plant)

    suspend fun deletePlant(id: Int) = dataSource.deletePlant(id)

    suspend fun deleteFromFav(plant: Plant) = dataSource.deleteFromFav(plant)

    suspend fun updateBasket(plant: Plant) = dataSource.updateBasket(plant)

    suspend fun getTotalPrice(): Int = dataSource.getTotalPrice()

    suspend fun deleteFromBasket(name:String) = dataSource.deleteFromBasket(name)

    suspend fun searchPlant(word: String): List<Plant> = dataSource.searchPlant(word)

    suspend fun updatePlant(count: Int, name: String) = dataSource.updatePlant(count, name)

   // suspend fun getAllBasket(): List<Plant> = dataSource.getAllBasket()

    fun login(email: String, password: String) = dataSource.login(email, password)

    fun register(userEmail: String, userPassword: String) =
        dataSource.register(userEmail, userPassword)

    fun getLiveUser() = dataSource.getLiveUser()

    fun updateImage(imageUrl: String) = dataSource.updateImage(imageUrl)
}