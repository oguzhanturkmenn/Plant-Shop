package com.oguzhanturkmen.myplantapp.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.Navigation
import com.oguzhanturkmen.myplantapp.R
import com.oguzhanturkmen.myplantapp.databinding.FragmentDashboardBinding
import com.oguzhanturkmen.myplantapp.ui.favorite.FavoriteAdapter
import com.oguzhanturkmen.myplantapp.utils.gecisYap
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class DashboardFragment : Fragment() {
    private lateinit var binding: FragmentDashboardBinding
    private val dashboardViewModel: DashboardViewModel by viewModels()
    private val dashboardAdapter by lazy { DashboardAdapter(dashboardViewModel::deletePlant,dashboardViewModel::addToFav) }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_dashboard, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.dashboardAdapter = dashboardAdapter

        binding.dashboardFragment = this
        dashboardViewModel.getDatas()
        observeLiveData()
    }

    private fun observeLiveData() {
        dashboardViewModel.list.observe(viewLifecycleOwner) {
            dashboardAdapter.submitList(it)
        }
    }


    fun letsSeeAllPlantsClicked() {
        Navigation.gecisYap(requireView(), R.id.plantFragment)
    }
}