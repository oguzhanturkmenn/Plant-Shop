package com.oguzhanturkmen.myplantapp.retrofit


import com.oguzhanturkmen.myplantapp.data.models.PlantResponse
import retrofit2.http.GET


interface PlantAPI {

    @GET("oguzhanturkmenn/bd8ee4476e50f4b7cc1ebffceb82cf6b/raw/57f2cc0650c73ce83011c234f6152fed497c33a2/plants.json")
    suspend fun getPlant(): PlantResponse
}