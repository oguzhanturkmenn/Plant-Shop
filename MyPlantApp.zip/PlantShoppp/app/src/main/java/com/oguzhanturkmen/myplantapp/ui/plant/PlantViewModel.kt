package com.oguzhanturkmen.myplantapp.ui.plant

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.oguzhanturkmen.myplantapp.data.models.Plant
import com.oguzhanturkmen.myplantapp.data.repo.PlantRepo
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PlantViewModel @Inject constructor(var plantRepo: PlantRepo) : ViewModel() {
    val list = MutableLiveData<List<Plant>>()

    init {
       getDatas()
    }

    fun getDatas() {
        viewModelScope.launch {
            list.value = plantRepo.loadPlants()
        }
    }

    fun addToFav(plant: Plant) {
        viewModelScope.launch {
            plantRepo.addToFav(plant)
        }
    }


    fun deleteFromFav(plant: Plant) {
        viewModelScope.launch {
            plantRepo.deleteFromFav(plant)
            Log.v("Viewmodel",plant.plantName!!)
        }
    }
}