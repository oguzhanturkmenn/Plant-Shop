package com.oguzhanturkmen.myplantapp.data.models

data class Answer(
    var success: Int?,
    var message: String?
) {
}