package com.oguzhanturkmen.myplantapp.ui.basket

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.oguzhanturkmen.myplantapp.R
import com.oguzhanturkmen.myplantapp.data.models.Plant
import com.oguzhanturkmen.myplantapp.databinding.FragmentBasketBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BasketFragment : Fragment(), BasketAdapterListener {
    private lateinit var binding: FragmentBasketBinding
    private lateinit var basketAdapter: BasketAdapter
    private lateinit var viewModel: BasketViewModel
    private val adapter by lazy {
        BasketAdapter(
            this,
            onRemoveBasketClick = ::onRemoveBasketClick,
            viewModel::increase,
            viewModel::decrease
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel = ViewModelProvider(this)[BasketViewModel::class.java]
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_basket, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //viewModel.getAllBasket()
        observeLiveData()
    }

    private fun onRemoveBasketClick(name:String) {
        viewModel.deleteFromBasket(name)
        viewModel.resetTotalAmount()
    }

    private fun observeLiveData() {
        viewModel.readAllBasket.observe(viewLifecycleOwner) {
            basketAdapter = BasketAdapter(this@BasketFragment)
            binding.basketAdapter = basketAdapter
            basketAdapter.submitList(it)

            viewModel.totalBasket()

            viewModel.totalAmount.observe(viewLifecycleOwner) {
                if (it == null) binding.tvTotalPriceBasketFragment.text = "0$"
                else binding.tvTotalPriceBasketFragment.text = getString(R.string.total_tl, it.toString())
            }
        }
    }


/*
    private fun observeLiveData() {
        viewModel.basketList.observe(viewLifecycleOwner) {
            basketAdapter = BasketAdapter(this@BasketFragment)
            binding.basketAdapter = basketAdapter
            basketAdapter.submitList(it)
        }
    }

 */



    override fun onDeleteClicked(name: String) {
        viewModel.deleteFromBasket(name)
    }


}