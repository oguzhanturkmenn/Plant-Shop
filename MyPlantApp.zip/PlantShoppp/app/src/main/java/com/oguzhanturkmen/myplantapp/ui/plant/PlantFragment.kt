package com.oguzhanturkmen.myplantapp.ui.plant

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.oguzhanturkmen.myplantapp.R
import com.oguzhanturkmen.myplantapp.databinding.FragmentPlantBinding
import com.oguzhanturkmen.myplantapp.ui.dashboard.DashboardAdapter
import com.oguzhanturkmen.myplantapp.ui.dashboard.DashboardViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class PlantFragment : Fragment() {
    private lateinit var binding: FragmentPlantBinding
    private val viewModel: PlantViewModel by viewModels()
    private val plantAdapter by lazy { PlantAdapter(viewModel::deleteFromFav, viewModel::addToFav)}

        override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_plant, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.plantAdapter =plantAdapter

        observeLiveData()
    }

    private fun observeLiveData() {
        viewModel.list.observe(viewLifecycleOwner) {
            plantAdapter.submitList(it)
        }
    }
}