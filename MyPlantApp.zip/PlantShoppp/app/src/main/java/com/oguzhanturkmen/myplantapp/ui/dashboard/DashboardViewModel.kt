package com.oguzhanturkmen.myplantapp.ui.dashboard

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.oguzhanturkmen.myplantapp.data.models.Answer
import com.oguzhanturkmen.myplantapp.data.models.Plant
import com.oguzhanturkmen.myplantapp.data.repo.PlantRepo
import com.oguzhanturkmen.myplantapp.ui.basket.BasketViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    var plantRepo: PlantRepo,
    var firebaseAuth: FirebaseAuth
) : ViewModel() {
    val list = MutableLiveData<List<Plant>>()


    fun getDatas() {
        viewModelScope.launch {
            list.value = plantRepo.loadPlants()
        }
    }

    fun addToBasket(plant: Plant) {
        viewModelScope.launch(Dispatchers.IO) {
            plantRepo.addToBasket(plant)
        }
    }

    fun addToFav(plant: Plant) {
        viewModelScope.launch {
            plantRepo.addToFav(plant)

        }
    }


    fun deletePlant(plant: Plant) {
        viewModelScope.launch {
            plantRepo.deletePlant(plant.id)
            getDatas()

        }
    }

    fun deleteFromFav(plant: Plant) {
        viewModelScope.launch {
            plantRepo.deleteFromFav(plant)
            getDatas()
        }
    }


}