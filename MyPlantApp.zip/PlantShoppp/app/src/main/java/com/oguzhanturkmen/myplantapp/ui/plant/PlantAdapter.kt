package com.oguzhanturkmen.myplantapp.ui.plant

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.navigation.Navigation
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.oguzhanturkmen.myplantapp.R
import com.oguzhanturkmen.myplantapp.data.models.Plant
import com.oguzhanturkmen.myplantapp.databinding.PlantRowBinding
import com.oguzhanturkmen.myplantapp.ui.dashboard.DashboardViewModel
import com.oguzhanturkmen.myplantapp.utils.gecisYap

class PlantAdapter( private val onRemoveFav: (Plant) -> Unit = {},
                    private val onAddFav: (Plant) -> Unit = {}) :

    ListAdapter<Plant, PlantAdapter.PlantHolder>(PlantDiffCallback()) {

    inner class PlantHolder(val binding: PlantRowBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(p: Plant) {
            binding.executePendingBindings()
            binding.plant = p
            binding.executePendingBindings()

            binding.llFav.setOnClickListener {
                if (p.plantFav) {
                    binding.imgHeartPlantrow.setImageResource(R.drawable.ic_heart)
                    p.plantFav = false
                    onRemoveFav(p)
                } else {
                    binding.imgHeartPlantrow.setImageResource(R.drawable.ic_heart_faved)
                    p.plantFav = true
                    onAddFav(p)
                }
            }

            if (p.plantFav) {
                binding.imgHeartPlantrow.setImageResource(R.drawable.ic_heart_faved)
            } else {
                binding.imgHeartPlantrow.setImageResource(R.drawable.ic_heart)
            }

            binding.cardView.setOnClickListener {
                val action =
                    PlantFragmentDirections.actionPlantFragmentToPlantDetailsFragment(p)
                Navigation.gecisYap(it, action)
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlantHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = DataBindingUtil.inflate<PlantRowBinding>(
            inflater, R.layout.plant_row, parent, false
        )
        return PlantHolder(binding)
    }

    override fun onBindViewHolder(holder: PlantHolder, position: Int) {
        val list = currentList[position]
        holder.bind(list)
    }

    class PlantDiffCallback : DiffUtil.ItemCallback<Plant>() {
        override fun areItemsTheSame(oldItem: Plant, newItem: Plant): Boolean {
            return oldItem.id == newItem.id &&
                    oldItem.plantName == newItem.plantName &&
                    oldItem.plantPrice == newItem.plantPrice
        }

        override fun areContentsTheSame(oldItem: Plant, newItem: Plant): Boolean {
            return oldItem == newItem
        }
    }
    override fun getItemCount() = currentList.size

}


