package com.oguzhanturkmen.myplantapp.ui.favorite

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.oguzhanturkmen.myplantapp.R
import com.oguzhanturkmen.myplantapp.data.models.Plant
import com.oguzhanturkmen.myplantapp.databinding.FavRowBinding

class FavoriteAdapter(private val onRemoveFavClick: (Plant) -> Unit = {}) :
    ListAdapter<Plant, FavoriteAdapter.FavoriteHolder>(FavoriteAdapter.FavoritePlantDiffCallback()) {

    inner class FavoriteHolder(val binding: FavRowBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(p: Plant) {
            binding.plant = p
            binding.executePendingBindings()

            binding.imgProductImgFavRow.setOnClickListener {
                onRemoveFavClick(p)
            }


            if (binding.plant!!.plantFav) {
                binding.imgHeartFavRow.setImageResource(R.drawable.ic_heart_faved)
            } else {
                binding.imgHeartFavRow.setImageResource(R.drawable.ic_heart)
            }


        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = DataBindingUtil.inflate<FavRowBinding>(
            inflater, R.layout.fav_row, parent, false
        )
        return FavoriteHolder(binding)
    }

    override fun onBindViewHolder(holder: FavoriteHolder, position: Int) {
        holder.bind(currentList[position])
    }

    override fun getItemCount(): Int {
        return currentList.size
    }

    class FavoritePlantDiffCallback : DiffUtil.ItemCallback<Plant>() {
        override fun areItemsTheSame(oldItem: Plant, newItem: Plant): Boolean {
            return oldItem.id == newItem.id &&
                    oldItem.plantName == oldItem.plantName &&
                    oldItem.plantPrice == newItem.plantPrice
        }

        override fun areContentsTheSame(oldItem: Plant, newItem: Plant): Boolean {
            return oldItem == newItem
        }
    }
}