package com.oguzhanturkmen.myplantapp.ui.basket

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.oguzhanturkmen.myplantapp.R
import com.oguzhanturkmen.myplantapp.data.models.Plant
import com.oguzhanturkmen.myplantapp.databinding.BasketRowBinding

class BasketAdapter(
    val listener: BasketAdapterListener,
    private val onRemoveBasketClick: (String) -> Unit = {},
    private val onIncreaseClick: (Plant) -> Unit = {},
    private val onDecreaseClick: (Plant) -> Unit = {}

) : ListAdapter<Plant, BasketAdapter.BasketHolder>(BasketPlantDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BasketHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = DataBindingUtil.inflate<BasketRowBinding>(
            inflater, R.layout.basket_row, parent, false
        )
        return BasketHolder(binding)
    }

    override fun onBindViewHolder(holder: BasketHolder, position: Int) {
        holder.bind(currentList[position])
    }

    inner class BasketHolder(val binding: BasketRowBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(p: Plant) {
            binding.plant = p
            binding.executePendingBindings()

            binding.llDelete.setOnClickListener {
                listener.onDeleteClicked(p.plantName!!)
            }

            binding.btnPlus.setOnClickListener {
                if (p.plantCount > p.count) {
                    Log.v("Count",p.plantCount.toString())
                    onIncreaseClick(p)
                    p.count++
                } else {
                    Toast.makeText(binding.root.context, "else", Toast.LENGTH_SHORT).show()
                }
            }

            binding.btnMinus.setOnClickListener {
                if (p.count != 1) {
                    onDecreaseClick(p)
                    p.count--
                } else {
                    listener.onDeleteClicked(p.plantName!!)
                }
            }


        }
    }


    override fun getItemCount(): Int {
        return currentList.size
    }

    class BasketPlantDiffCallback : DiffUtil.ItemCallback<Plant>() {
        override fun areItemsTheSame(oldItem: Plant, newItem: Plant): Boolean {
            return oldItem.id == newItem.id &&
                    oldItem.plantName == oldItem.plantName &&
                    oldItem.plantCount == oldItem.plantCount &&
                    oldItem.plantPrice == newItem.plantPrice
        }

        override fun areContentsTheSame(oldItem: Plant, newItem: Plant): Boolean {
            return oldItem == newItem
        }
    }

}

interface BasketAdapterListener {
    fun onDeleteClicked(name: String)
}
