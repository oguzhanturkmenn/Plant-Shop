package com.oguzhanturkmen.myplantapp.ui.dashboard

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.navigation.Navigation
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.oguzhanturkmen.myplantapp.R
import com.oguzhanturkmen.myplantapp.data.models.Plant
import com.oguzhanturkmen.myplantapp.databinding.PlantRowBinding
import com.oguzhanturkmen.myplantapp.utils.gecisYap

class DashboardAdapter(
    private val onRemoveFav: (Plant) -> Unit = {},
    private val onAddFav: (Plant) -> Unit = {},
    //private val onAddBasket: (Plant) -> Unit = {}

) : ListAdapter<Plant, DashboardAdapter.DashboardHolder>(DashboardPlantDiffCallback()) {


    inner class DashboardHolder(val binding: PlantRowBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(p: Plant) {
            binding.plant =p
            binding.executePendingBindings()

            binding.llFav.setOnClickListener {
                if (p.plantFav) {
                    binding.imgHeartPlantrow.setImageResource(R.drawable.ic_heart)
                    p.plantFav = false
                    onRemoveFav(p)
                    Log.v("Fav",p.plantFav.toString())
                } else {
                    binding.imgHeartPlantrow.setImageResource(R.drawable.ic_heart_faved)
                    p.plantFav = true
                    onAddFav(p)
                    Log.v("Fav",p.plantFav.toString())
                }
            }

            if (p.plantFav) {
                binding.imgHeartPlantrow.setImageResource(R.drawable.ic_heart_faved)
            } else {
                binding.imgHeartPlantrow.setImageResource(R.drawable.ic_heart)
            }
/*
            binding.btnAddToBasketPlantRow.setOnClickListener {
                onAddBasket(
                    .let { product ->
                        BasketModel(
                            0,
                            product.id!!,
                            product.img!!,
                            product.productTitle!!,
                            product.productPrice!!.toInt(),
                            product.productCount!!
                        )

                    }
                )
                requireView().showErrorSnackBar(getString(R.string.product_add), false)
            }

 */

            binding.cardView.setOnClickListener {
                val action =
                    DashboardFragmentDirections.actionDashboardFragmentToPlantDetailsFragment(p)
                Navigation.gecisYap(it, action)
            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashboardHolder {
        val binding: PlantRowBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.plant_row, parent, false
        )
        return DashboardHolder(binding)
    }

    override fun onBindViewHolder(holder: DashboardHolder, position: Int) {
        holder.bind(currentList[position])

    }


    class DashboardPlantDiffCallback : DiffUtil.ItemCallback<Plant>() {
        override fun areItemsTheSame(oldItem: Plant, newItem: Plant): Boolean {
            return oldItem.id == newItem.id &&
                    oldItem.plantName == oldItem.plantName &&
                    oldItem.plantPrice == newItem.plantPrice
        }

        override fun areContentsTheSame(oldItem: Plant, newItem: Plant): Boolean {
            return oldItem == newItem
        }
    }

    override fun getItemCount() = currentList.size
}