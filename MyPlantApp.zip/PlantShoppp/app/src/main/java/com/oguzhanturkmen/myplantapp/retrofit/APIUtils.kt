package com.oguzhanturkmen.myplantapp.retrofit


class APIUtils {
    companion object {
        val BASE_URL = "https://gist.githubusercontent.com/"
        fun plantAPIGet(): PlantAPI {
            return RetrofitBuilder
                .getClient(BASE_URL)
                .create(PlantAPI::class.java)
        }
    }
}